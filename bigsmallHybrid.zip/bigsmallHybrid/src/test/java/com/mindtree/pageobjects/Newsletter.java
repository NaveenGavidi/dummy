package com.mindtree.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Newsletter {

	public WebDriver driver;

	public Newsletter(WebDriver driver) {
		this.driver = driver;
	}

	
	By email = By.xpath("//input[@type='email']");
	By subscribe = By.xpath("//button[@id='subscribe']");
	
	

	
	public WebElement getemail() {
		return driver.findElement(email);
	}

	public WebElement getsubscribe() {
		return driver.findElement(subscribe);
	}

	


}
