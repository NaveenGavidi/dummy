package com.mindtree.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPageLC {
	
	public  WebDriver driver;
	public LoginPageLC(WebDriver driver)
	{
		this.driver=driver;
	}

	By homeSignInButton=By.xpath("//div[@class='site-nav__icons']//a[1]");
	By emailBox=By.cssSelector("input[id='CustomerEmail']");
	By passwordBox=By.cssSelector("input[id='CustomerPassword']");
	By loginSignButton=By.xpath("(//input[@type='submit'])[1]");
	By newAccount=By.cssSelector("a[href*='register']");
	By fname=By.xpath("//input[@id='FirstName']");
	By lname=By.xpath("//input[@id='LastName']");
	By cemail=By.xpath("//input[@id='Email']");
	By cpassword=By.xpath("//input[@id='CreatePassword']");
	By create=By.xpath("//input[@type='submit']");
	
	public WebElement getHomeSignInButtond() {
		return driver.findElement(homeSignInButton);
	}
	
	public WebElement getemailBox() {
		return driver.findElement(emailBox);
	}
	
	public WebElement getpasswordBox() {
		return driver.findElement(passwordBox);
	}
	
	public WebElement getLoginSignButton()
	{
		return driver.findElement(loginSignButton);
	}
	
	//New account creation
	public WebElement getcreateaccount() {
		return driver.findElement(newAccount);
	}
	
	public WebElement getfname() {
		return driver.findElement(fname);
	}
	
	public WebElement getlname() {
		return driver.findElement(lname);
	}
	
	public WebElement getcemail() {
		return driver.findElement(cemail);
	}
	
	public WebElement getcpassword() {
		return driver.findElement(cpassword);
	}
	
	public WebElement getcreate() {
		return driver.findElement(create);
	}

}
