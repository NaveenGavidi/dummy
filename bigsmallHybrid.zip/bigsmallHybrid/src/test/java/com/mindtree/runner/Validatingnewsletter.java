package com.mindtree.runner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.mindtree.pageobjects.Newsletter;
import com.mindtree.reusablecomponent.Base;

public class Validatingnewsletter extends Base {

	public static Logger log = LogManager.getLogger(Validatingnewsletter.class.getName());
	
	@BeforeMethod
	public void OpenBrowser() throws Exception {
		driver = initializeDriver();
	}
	
	@Test
	public void verifynews() throws Exception {
		test.info("Browser Opened");
		log.info("Browser Opened");
		driver.get(property.getUrl());
		log.info("Navigate to Url : " + driver.getCurrentUrl());
		test.info("Navigate to Url " + driver.getCurrentUrl());
		Newsletter nl=new Newsletter(driver);
		
		test.info("Entering Email for newsletter subscription");
		log.info("Entering Email for newsletter subscription");
		nl.getemail().click();
		nl.getemail().sendKeys(property.getEmail());
		test.info("Clicking on subscription method");
		log.info("Clicking on subscription method");
		nl.getsubscribe().click();
		test.fail("Not Redirected to newsletter page");
		log.info("Not Redirected to newsletter page");
	}
}
