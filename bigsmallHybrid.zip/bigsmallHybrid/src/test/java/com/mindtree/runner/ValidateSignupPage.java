package com.mindtree.runner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.mindtree.pageobjects.LoginPageLC;
import com.mindtree.reusablecomponent.Base;
import com.mindtree.utilities.excelSheet;

public class ValidateSignupPage extends Base {

	public static Logger log = LogManager.getLogger(ValidateSignupPage.class.getName());

	@BeforeMethod
	public void OpenBrowser() throws Exception {
		driver = initializeDriver();
	}

	@Test
	public void loginPage() throws Exception {
		// test.info("Browser Opened");
		log.info("Browser Opened");
		driver.get(property.getUrl());
		log.info("Navigate to Url : " + driver.getCurrentUrl());
		test.info("Navigate to Url "+driver.getCurrentUrl());
		//Creating object of login page locator class
		LoginPageLC lg=new LoginPageLC(driver);
		//click on sign in Button on HomePage
		test.info("Clicling on SignIn Button");
		lg.getHomeSignInButtond().click();
		log.info("clicked on SignIn Button");
		log.info("navigated to Login Page");
		test.info("navigated to Login Page");
		//click on create new account
		test.info("Clicling on create new account Button");
		lg.getcreateaccount().click();
		log.info("clicked on create new account Button");
		//sending First name from excel sheet to Sign-in page
				log.info("getting First name from excel and sending to First name");
				test.info("Entering First name");
				lg.getfname().sendKeys(excelSheet.getExcelSheetData("sheet1",1,2));
		//sending Last name from excel sheet to Sign-in page
				log.info("getting Last name from excel and sending to Last name");
				test.info("Entering Last name");
				lg.getlname().sendKeys(excelSheet.getExcelSheetData("sheet1",1,3));		
				
		//sending email address from excel sheet to Sign-in page
		log.info("getting email addreess from excel and sending to email");
		test.info("Entering email");
		lg.getcemail().sendKeys(excelSheet.getExcelSheetData("sheet1",1,0));
		//sending Password from excelSheet to Sign-in page
		log.info("getting password from excelSheet and sending to password");
		test.info("Entering password");
		lg.getcpassword().sendKeys(excelSheet.getExcelSheetData("sheet1", 1, 1));
		//Clicking on create Button
		log.info("clicking on create Button");
		test.info("Clicking create Button");
		lg.getcreate().click();
		test.pass("Succesfully Created new User");
	}
}
